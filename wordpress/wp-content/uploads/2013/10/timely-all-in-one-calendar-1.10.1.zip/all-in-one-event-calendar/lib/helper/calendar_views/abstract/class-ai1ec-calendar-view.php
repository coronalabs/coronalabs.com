<?php

/**
 * @author Timely Network Inc
 */

abstract class Ai1ec_Calendar_View implements Ai1ec_Renderable {
	public function __construct(  ) {

	}
}

?>
