<?php

/**
 * Place any custom WordPress hooks or theme functions into this file. In most
 * cases this file can remain untouched.
 */

?>
