<?php

/** 
 * @author Then.ly
 * 
 * 
 */

class Ai1ec_Too_Early_For_Wp_Script_Exception extends Exception {

}