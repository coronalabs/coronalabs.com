<?php
//
//  class-ai1ec-exporter.php
//  all-in-one-event-calendar
//
//  Created by The Seed Studio on 2011-07-13.
//

/**
 * Ai1ec_Event class
 *
 * @package Models
 * @author time.ly
 **/
class Ai1ec_Exporter {

	function __construct() {

	}

	function export( $events, $format = "ics" ) {

	}

	function export_to_ics() {

	}
}
// END class
