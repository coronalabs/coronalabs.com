<div class="ai1ec_repeat_centered_content">
  <label for="ai1ec_daily_count">
	  <?php _e( 'Every', AI1EC_PLUGIN_NAME ) ?>:
  </label>
  <?php echo $count ?>
</div>