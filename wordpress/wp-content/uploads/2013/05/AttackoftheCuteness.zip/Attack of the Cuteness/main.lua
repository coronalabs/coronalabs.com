-- Project: Attack of the Cuteness Game
-- http://MasteringCoronaSDK.com
-- Version: 1.0
-- Copyright 2013 J. A. Whye. All Rights Reserved.
-- "Space Cute" art by Daniel Cook (Lostgarden.com) 

-- housekeeping stuff

display.setStatusBar(display.HiddenStatusBar)

local centerX = display.contentCenterX
local centerY = display.contentCenterY

-- set up forward references


-- preload audio


-- create play screen


-- game functions

function spawnEnemy()

end


function startGame()

end


local function planetDamage()

end


function hitPlanet(obj)

end


function shipSmash(event)

end

startGame()

